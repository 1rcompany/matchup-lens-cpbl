"""Exploratory temporal MLP benchmark and descriptive zone aggregates. No test tuning."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from build import extract,Model,scores,ROOT
import numpy as np,json,collections as C
from sklearn.preprocessing import OneHotEncoder
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import log_loss,brier_score_loss
from threadpoolctl import threadpool_limits
threadpool_limits(1)
rows,_,_=extract();ref=[r for r in rows if r[0]==2024];tr=[r for r in ref if r[9] and r[1]<'2024-08-01'];va=[r for r in ref if r[9] and r[1]>='2024-08-01'];te=[r for r in rows if r[0]==2025 and r[9]]
def features(rs):return [[r[3],r[4],r[5],r[6],r[7],r[8]] for r in rs]
def ys(rs):return np.array([r[10] for r in rs])
enc=OneHotEncoder(handle_unknown='ignore',dtype=np.float32);x=enc.fit_transform(features(tr));v=enc.transform(features(va));grid=[];best=(float('inf'),None,None)
for alpha in [1.,10.,100.]:
 m=MLPClassifier(hidden_layer_sizes=(32,16),alpha=alpha,batch_size=512,learning_rate_init=.001,random_state=20261107,shuffle=True)
 for epoch in range(1,21):
  m.partial_fit(x,ys(tr),classes=[0,1]);ll=log_loss(ys(va),m.predict_proba(v)[:,1]);grid.append({'alpha':alpha,'epoch':epoch,'validation_log_loss':ll})
  if ll<best[0]:best=(ll,alpha,epoch)
 print('completed alpha',alpha,'best',best,flush=True)
# Fit preprocessing and network anew using only 2024; never select on 2025.
enc=OneHotEncoder(handle_unknown='ignore',dtype=np.float32);x=enc.fit_transform(features([r for r in ref if r[9]]));rr=[r for r in ref if r[9]]
m=MLPClassifier(hidden_layer_sizes=(32,16),alpha=best[1],batch_size=512,learning_rate_init=.001,random_state=20261107,shuffle=True)
for _ in range(best[2]):m.partial_fit(x,ys(rr),classes=[0,1])
p=m.predict_proba(enc.transform(features(te)))[:,1];y=ys(te);old=Model(ref);q=np.array([old.predict(r,60)[3] for r in te]);diff=(p-y)**2-(q-y)**2
groups=C.defaultdict(list)
for i,r in enumerate(te):groups[r[2]].append(i)
sizes=np.array([len(i) for i in groups.values()]);sums=np.array([diff[i].sum() for i in groups.values()]);rng=np.random.default_rng(20261107);draw=rng.integers(0,len(groups),(2000,len(groups)));boot=sums[draw].sum(1)/sizes[draw].sum(1)
meta={'architecture':[32,16],'encoding':'one-hot; unknown categories all zero','features':['batter_id','pitcher_id','pitch_type','batter_hand','pitcher_hand','pre_pitch_count'],'alpha':best[1],'epochs':best[2],'seed':20261107,'parameters':sum(a.size for a in m.coefs_)+sum(a.size for a in m.intercepts_),'train_swings':len(rr),'validation_swings':len(va),'test_swings':len(te),'brier':brier_score_loss(y,p),'log_loss':log_loss(y,p),'delta_vs_shrink':float(diff.mean()),'ci95':np.quantile(boot,[.025,.975]).tolist(),'grid':grid,'status':'exploratory; 2025 previously inspected for incumbent model; new independent season required','unseen_batter_swings':sum(r[3] not in enc.categories_[0] for r in te),'unseen_pitcher_swings':sum(r[4] not in enc.categories_[1] for r in te)}
# ten cells: 9 inside, 1 outside; pooled over counts to preserve samples.
zone={role:{} for role in ['p','b','league']}
for r in ref:
 if r[11]<0:continue
 for role,k in [('p','|'.join([r[4],r[6],r[5]])),('b','|'.join([r[3],r[7],r[5]])),('league','|'.join([r[6],r[7],r[5]]))]:
  a=zone[role].setdefault(k,[[0,0,0]for _ in range(10)])[r[11]];a[0]+=1;a[1]+=r[9];a[2]+=r[10]
(ROOT/'dist/pitch-lab.json').write_text(json.dumps({'meta':meta,'zone':zone},ensure_ascii=False,separators=(',',':')))
(ROOT/'analysis/pitch/deep-results.json').write_text(json.dumps(meta,indent=2))
# Persist reproducible trained weights without unsafe pickle.
np.savez_compressed(ROOT/'analysis/pitch/mlp-weights.npz',**{f'w{i}':a for i,a in enumerate(m.coefs_)},**{f'b{i}':a for i,a in enumerate(m.intercepts_)})
(ROOT/'analysis/pitch/mlp-categories.json').write_text(json.dumps([a.tolist()for a in enc.categories_]))
print(json.dumps({k:v for k,v in meta.items() if k!='grid'},indent=2))
