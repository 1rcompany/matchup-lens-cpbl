"""Audited pre-pitch counts, pitch scouting and frozen-season swing-miss validation."""
import collections as C,json,math,pathlib,zipfile,hashlib
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[2]
RAW=ROOT/'data/raw'
KNOWN={'S','SW','B','F','FT','H'};SWING={'SW','F','FT','H'}
TYPES={'FF','SI','FC','SL','CU','CH','FO','FS','KN','EP'}
HASH={2024:'1711009c9d3bac68ca13b2b68f409587fdce2deea3c9fbb5ad68131fccb1d19f',2025:'eb84d824e0fdce032a47aebcad5d2f64610629adbb806dd23d7e282eb6d390f6'}

def extract():
 rows=[];audit={};players={'b':{},'p':{}}
 for year in [2024,2025]:
  path=RAW/f'CPBL-{year}-OpenData.zip';assert hashlib.sha256(path.read_bytes()).hexdigest()==HASH[year]
  a=C.Counter();excluded=C.Counter()
  with zipfile.ZipFile(path) as z:
   for name in sorted(z.namelist()):
    if not name.endswith('.json') or name.endswith('OpenData.json'):continue
    g=json.loads(z.read(name));a['games']+=1
    for side,other in [('home','away'),('away','home')]:
     maps={role:{x['playerName']:x['playerId'] for x in g[box]} for role,box in [('b',side+'BatterBox'),('p',other+'PitcherBox')]}
     for pa in g[side+'PAList']:
      events=pa.get('events',[]);pitches=[e for e in events if e['type']=='PITCH'];a['all_pitches']+=len(pitches)
      for e in pitches:
       a['pitch_type_present']+=int(e.get('pitchType') in TYPES)
       try:float(e['coordX']);float(e['coordY']);a['coordinates_present']+=1
       except (ValueError,TypeError,KeyError):pass
      if any(e['type']=='NO_PITCH' for e in events):excluded['pa_with_no_pitch_event']+=len(pitches);continue
      if any(e.get('pitchCode') not in KNOWN for e in pitches):excluded['pa_with_bunt_or_unknown_code']+=len(pitches);continue
      balls=strikes=0;valid=True
      for e in pitches:
       if balls>3 or strikes>2:excluded['after_terminal_count']+=1;valid=False;break
       b=maps['b'].get(e.get('batterName'));p=maps['p'].get(e.get('pitcherName'));t=e.get('pitchType');bh=pa.get('batterHand');ph=pa.get('pitcherHand')
       if not b or not p or t not in TYPES or bh not in ['L','R'] or ph not in ['L','R']:excluded['missing_id_type_or_hand']+=1
       else:
        code=e['pitchCode'];zone=-1
        try:
         x,y=float(e['coordX']),float(e['coordY']);zone=9 if abs(x)>50 or abs(y)>60 else min(2,int((60-y)/40))*3+min(2,int((x+50)/ (100/3)))
        except (ValueError,TypeError,KeyError):pass
        rows.append([year,g['date'][:10],f'{year}-{g["seq"]}',b,p,t,bh,ph,f'{balls}-{strikes}',int(code in SWING),int(code=='SW'),zone])
        a['eligible_pitches']+=1;a['swings']+=int(code in SWING);a['whiffs']+=int(code=='SW')
        if year==2024:
         for role,pid,nm,team,hand in [('b',b,e['batterName'],g[side+'Team'],bh),('p',p,e['pitcherName'],g[other+'Team'],ph)]:
          old=players[role].get(pid)
          if old is None or old['date']<g['date']:players[role][pid]={'id':pid,'name':nm,'team':team,'hand':hand,'date':g['date']}
       if e['pitchCode']=='B':balls+=1
       elif e['pitchCode'] in ['S','SW','FT']:strikes+=1
       elif e['pitchCode']=='F':strikes=min(2,strikes+1)
       elif e['pitchCode']=='H':break
  a['excluded_pitches']=a['all_pitches']-a['eligible_pitches'];assert a['games']==360
  audit[str(year)]={**a,'exclusion_counts':dict(excluded),'sha256':HASH[year]}
 return rows,players,audit

def key(r):return '|'.join([r[5],r[8],r[6],r[7]])
class Model:
 def __init__(self,rows):
  self.base=C.defaultdict(lambda:[0,0]);self.b=C.defaultdict(lambda:[0,0]);self.p=C.defaultdict(lambda:[0,0]);self.n=self.k=0
  for r in rows:
   if not r[9]:continue
   self.n+=1;self.k+=r[10]
   for m,k in [(self.base,key(r)),(self.b,'|'.join([r[3],r[5],r[7]])),(self.p,'|'.join([r[4],r[5],r[6]]))]:m[k][0]+=1;m[k][1]+=r[10]
  self.q=self.k/self.n
 def predict(self,r,s):
  n,k=self.base.get(key(r),(0,0));base=(k+100*self.q)/(n+100)
  bn,bk=self.b.get('|'.join([r[3],r[5],r[7]]),(0,0));pn,pk=self.p.get('|'.join([r[4],r[5],r[6]]),(0,0))
  # Context + separately shrunken player deviations; observational, not a causal pitch effect.
  qb=(bk+s*base)/(bn+s);qp=(pk+s*base)/(pn+s)
  logit=lambda x:math.log(x/(1-x))
  estimate=1/(1+math.exp(-(logit(qb)+logit(qp)-logit(base))))
  return [self.q,base,qp,estimate]

def scores(rows,p):
 y=np.array([r[10] for r in rows]);p=np.clip(np.asarray(p),1e-8,1-1e-8);return (p-y[:,None])**2,-(y[:,None]*np.log(p)+(1-y[:,None])*np.log1p(-p))

def aggregate(rows,role):
 out=C.defaultdict(lambda:[0,0,0]+[0]*10)
 for r in rows:
  k='|'.join([r[3] if role=='b' else r[4],r[7] if role=='b' else r[6],r[8],r[5]])
  v=out[k];v[0]+=1;v[1]+=r[9];v[2]+=r[10]
  if r[11]>=0:v[3+r[11]]+=1
 return dict(out)

def main():
 rows,players,audit=extract();train=[r for r in rows if r[0]==2024 and r[1]<'2024-08-01'];val=[r for r in rows if r[0]==2024 and r[1]>='2024-08-01' and r[9]];test=[r for r in rows if r[0]==2025 and r[9]];ref=[r for r in rows if r[0]==2024]
 m=Model(train);grid=[]
 for s in [20,60,150,400,1000]:
  br,ll=scores(val,[m.predict(r,s) for r in val]);grid.append({'strength':s,'log_loss':float(ll[:,3].mean()),'pitcher_log_loss':float(ll[:,2].mean())})
 s=min(grid,key=lambda x:x['log_loss'])['strength'];baseline_s=min(grid,key=lambda x:x['pitcher_log_loss'])['strength'];m=Model(ref);pred=[m.predict(r,s) for r in test];
 for i,r in enumerate(test):pred[i][2]=m.predict(r,baseline_s)[2]
 br,ll=scores(test,pred);names=['league','count_type_hand','pitcher','combined'];metrics={name:{'brier':float(br[:,i].mean()),'log_loss':float(ll[:,i].mean())} for i,name in enumerate(names)}
 groups=C.defaultdict(list)
 for i,r in enumerate(test):groups[r[2]].append(i)
 sizes=np.array([len(v) for v in groups.values()]);sums=np.array([br[v].sum(axis=0) for v in groups.values()]);rng=np.random.default_rng(20261107);draw=rng.integers(0,len(groups),(2000,len(groups)));boot=sums[draw].sum(axis=1)/sizes[draw].sum(axis=1)[:,None]
 delta={name:{'difference':float((br[:,3]-br[:,i]).mean()),'ci95':np.quantile(boot[:,3]-boot[:,i],[.025,.975]).tolist()}for i,name in enumerate(names[:-1])}
 out={'meta':{'generated':'2026-11-07','reference_year':2024,'test_year':2025,'audit':audit,'strength':s,'pitcher_baseline_strength':baseline_s,'grid':grid,'metrics':metrics,'delta':delta,'validation_swings':len(val),'test_swings':len(test),'base_strength':100,'league_whiff':m.q,'count_rule':'投球前球數；排除含 NO_PITCH 或觸擊/未知代碼的整個打席；揮棒 SW/F/FT/H，揮空僅 SW；FT 不計為揮空。','coordinate_rule':'投手視角；以 x±50、y±60 為示意好球帶，非判決或精密量測。'},'players':players,'b':aggregate(ref,'b'),'p':aggregate(ref,'p'),'base':dict(m.base)}
 (ROOT/'dist/pitch-data.json').write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')))
 (ROOT/'analysis/pitch/results.json').write_text(json.dumps(out['meta'],ensure_ascii=False,indent=2))
 print(json.dumps(out['meta'],ensure_ascii=False,indent=2))
if __name__=='__main__':main()
