import json,pathlib,random,sys
from build import extract,Model
root=pathlib.Path(__file__).resolve().parents[2]
rows,players,audit=extract();ref=[r for r in rows if r[0]==2024];m=Model(ref);d=json.loads((root/'dist/pitch-data.json').read_text());s=d['meta']['strength']
assert sum(v[0] for v in d['p'].values())==audit['2024']['eligible_pitches']
assert sum(v[1] for v in d['b'].values())==audit['2024']['swings']
assert sum(v[2] for v in d['p'].values())==audit['2024']['whiffs']
assert all(int(r[8][0])<=3 and int(r[8][-1])<=2 for r in rows)
assert all(v['date'][:4]=='2024' for group in players.values() for v in group.values())
fixtures=[]
for r in random.Random(42).sample(ref,200):fixtures.append({'b':r[3],'p':r[4],'type':r[5],'count':r[8],'expected':m.predict(r,s)[3]})
(root/'analysis/pitch/parity-fixtures.json').write_text(json.dumps(fixtures))
print('PASS: aggregate reconciliation, count range, 2024-only metadata, 200 Python parity fixtures')
