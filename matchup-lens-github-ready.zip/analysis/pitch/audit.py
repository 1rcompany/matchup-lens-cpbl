import zipfile,json,collections,pathlib
raw=pathlib.Path(__file__).resolve().parents[2]/'data/raw'
for year in [2024,2025]:
 c=collections.Counter();types=collections.Counter();codes=collections.Counter();evtypes=collections.Counter();coords=[]
 with zipfile.ZipFile(raw/f'CPBL-{year}-OpenData.zip') as z:
  for n in z.namelist():
   if not n.endswith('.json') or n.endswith('OpenData.json'):continue
   g=json.loads(z.read(n))
   for side in ['home','away']:
    for pa in g[side+'PAList']:
     for e in pa.get('events',[]):
      evtypes[e['type']]+=1
      if e['type']!='PITCH':continue
      c['pitches']+=1;types[e.get('pitchType','')]+=1;codes[e.get('pitchCode','')]+=1
      for k in ['pitchType','velocity','coordX','coordY']:
       if e.get(k,'') not in ['',None]:c[k]+=1
      try:coords.append((float(e['coordX']),float(e['coordY'])))
      except:pass
 print(year,dict(c),dict(types),dict(codes),dict(evtypes));print('ranges',min(x for x,y in coords),max(x for x,y in coords),min(y for x,y in coords),max(y for x,y in coords))
