"""Export saved dense MLP for dependency-free browser inference and parity tests."""
import json,numpy as np
from build import ROOT,extract
weights=np.load(ROOT/'analysis/pitch/mlp-weights.npz');cats=json.loads((ROOT/'analysis/pitch/mlp-categories.json').read_text());out={'categories':cats,'weights':[weights[f'w{i}'].tolist()for i in range(3)],'biases':[weights[f'b{i}'].tolist()for i in range(3)]}
(ROOT/'dist/pitch-mlp.json').write_text(json.dumps(out,separators=(',',':')))
rows,_,_=extract();fixtures=[]
for r in [r for r in rows if r[0]==2025][::1000]:
 f=[r[3],r[4],r[5],r[6],r[7],r[8]];a=np.concatenate([np.array([v==f[i] for v in c],dtype=float)for i,c in enumerate(cats)])
 for i in range(3):
  a=a@weights[f'w{i}']+weights[f'b{i}'];a=np.maximum(a,0)if i<2 else 1/(1+np.exp(-a))
 fixtures.append({'features':f,'expected':float(a[0])})
(ROOT/'analysis/pitch/mlp-fixtures.json').write_text(json.dumps(fixtures))
print('Exported browser MLP and',len(fixtures),'2025 parity fixtures')
